package fr.uvsq.pglp.kholle;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class AppTest {
	
	@Test
	public void test() {
		assertEquals(1,1);
	}

}